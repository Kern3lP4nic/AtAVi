'use strict';

const db = require("./DatabaseInteraction/DatabaseInteraction.js");
const table = "admin";
const crypto = require('crypto');
const jsontest = require("./TestJson");
//const codekey =  'lekfkghfkhfjhfkditc';

module.exports = {
   sendEmail: function (mail, callback) {
      //TODO
   },
   passwordRecoveryToken: function (token, mail, password, callback) {
      //TODO
   },
   logout: function (token, username, callback) {
      db.conditionUpdate(table, {"username": username}, "SET tkn = :val", "tkn = :val2", {
         ":val": " ",
         ":val2": token
      }, callback);
   },

   login: function (username, password, callback) {
      //codifico la password
      var pass = crypto.createHash('md5').update(password).digest("hex");

      db.queryProp(table, "username , email , superadmin", "username = :ml and password = :psw", {
            ":ml": username,
            ":psw": pass
         },
         function (err, res) {
            var result = null;
            if (!err && res.length > 0) {
               var token = crypto.createHash('md5').update((new Date().getTime() + username)).digest("hex");
               result = null;
               db.update(table, {"username": username}, "SET tkn = :val", {":val": token}, function (err, res2) {
                  if (!err) {
                     result = res[0];
                     result.token = token;
                  }
                  callback(err, result);
               });
            } else {
               err = {Error: "Invalid administrator credential", TypeError: "InvalidAdminCredential"};
               callback(err, null);
            }
         });
   },
   verifyLogin: function (token, callback) { //ok non toccare da testare ma funzionante
      db.queryProp(table, "username , email , superadmin", "tkn = :tokn", {":tokn": token}, function (err, res) {
         var result = null;
         if (!err && res.length > 0) {
            result = res[0];
         } else
            err = {Error: "Invalid administrator token", TypeError: "InvalidAdminToken"};
         callback(err, result);
      });
   },
   validateAuth: function (obj) {
      return jsontest.test(require('./JSONschema/Auth.json'), obj);
   }
};
