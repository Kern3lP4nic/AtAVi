'use strict';
const fs = require("../index.js");


var chai = require("chai");
var assert = chai.assert;
var expect = chai.expect;

const event1={
    httpMethod:"GET",
    resource:"/ManageSlack/DefaultInterlocutors",
    headers:{token:"0123456789"}
}

const event2={
    httpMethod:"GET",
    resource:"/ManageSlack/Interlocutors",
    headers:{token:"0123456789"}
}
const eventPOST={
    httpMethod:"POST",
    resource:"/ManageSlack/DefaultInterlocutors",
    headers:{token:"0123456789"},
    body:"{\"id_slack\":\"azz\",\"isDefault\":true,\"nameI\":\"kwerjhewrh\"}"
};
const eventDELETE={
    httpMethod:"DELETE",
    resource:"/ManageSlack/DefaultInterlocutors",
    headers:{token:"0123456789"},
    body:"{\"id_slack\":\"azz\",\"isDefault\":true,\"nameI\":\"kwerjhewrh\"}"
};
const eventPUT={
    httpMethod:"PUT",
    resource:"/ManageSlack/Interlocutors",
    headers:{token:"0123456789"}
}

var expect1={
  "Error": "",
  "TypeError": "",
  "Object": null
};


describe("ManageFirm", function () {
    context("request bad token GET /Manageslack/DefaultInterlocutors", function () {
        it("ok bad token", function (done) {
            fs.handler(event1,{}, function (err,data) {
                expect(err).to.equal(null);
                expect(data).to.deep.equal({
                    statusCode: '400',
                    body: JSON.stringify(expect1),
                    headers: {'Content-Type': 'application/json'}
                });
                done();
            });
        });
    });

    context("request call GET /Manageslack/DefaultInterlocutors", function () {
        it("ok request", function (done) {
            fs.handler(event1,{}, function (err,data) {
                expect(err).to.equal(null);
                expect(data).to.deep.equal({
                    statusCode: '200',
                    body: JSON.stringify(expect1),
                    headers: {'Content-Type': 'application/json'}
                });
                done();
            });
        });
    });

    context("request call GET /Manageslack/Interlocutors", function () {
        it("ok request", function (done) {
            fs.handler(event2,{}, function (err,data) {
                expect(err).to.equal(null);
                expect(data).to.deep.equal({
                    statusCode: '200',
                    body: JSON.stringify(expect1),
                    headers: {'Content-Type': 'application/json'}
                });
                done();
            });
        });
    });

    context("request call POST /Manageslack/DefaultInterlocutors", function () {
        it("ok request", function (done) {
            fs.handler(eventPOST,{}, function (err,data) {
                expect(err).to.equal(null);
                expect(data).to.deep.equal({
                    statusCode: '200',
                    body: JSON.stringify(expect1),
                    headers: {'Content-Type': 'application/json'}
                });
                done();
            });
        });
    });
    context("request call DELETE /Manageslack/DefaultInterlocutors", function () {
        it("ok request", function (done) {
            fs.handler(eventDELETE,{}, function (err,data) {
                expect(err).to.equal(null);
                expect(data).to.deep.equal({
                    statusCode: '200',
                    body: JSON.stringify(expect1),
                    headers: {'Content-Type': 'application/json'}
                });
                done();
            });
        });
    });
    context("request call PUT /Manageslack/interlocutors", function () {
        it("ok request", function (done) {
            fs.handler(eventPUT,{}, function (err,data) {
                expect(err).to.equal(null);
                expect(data).to.deep.equal({
                    statusCode: '200',
                    body: JSON.stringify(expect1),
                    headers: {'Content-Type': 'application/json'}
                });
                done();
            });
        });
    });
});